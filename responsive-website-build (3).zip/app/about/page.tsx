"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useState } from "react"
import { Mail, Phone, Printer, MapPin } from "lucide-react"
import Image from "next/image"

type TabType = "greeting" | "history" | "contact" | "location"

export default function AboutPage() {
  const [activeTab, setActiveTab] = useState<TabType>("greeting")

  const tabs: { id: TabType; label: string }[] = [
    { id: "greeting", label: "인사말" },
    { id: "history", label: "연혁" },
    { id: "contact", label: "연락처" },
    { id: "location", label: "오시는 길" },
  ]

  const history = [
    { year: "1998", event: "세광정밀 설립" },
    { year: "2008", event: "경기동부상공회의소 회원" },
    { year: "2018", event: "일자리 창출 기여 경기도지회의장 표창장" },
    { year: "2018", event: "일자리 창출 기여 국회의원 표창장" },
    { year: "2019", event: "경기도중소기업CEO연합회 인증기업" },
    { year: "2019", event: "경기도중소기업CEO연합회 표창장" },
    { year: "2019", event: "중소기업융합경기협회 융합회원사" },
    { year: "2020", event: "한국기업데이터 기술역량 우수기업 인증" },
    { year: "2021", event: "지역경제 활성화 경기도지사 표창장" },
    { year: "2021", event: "지역경제 활성화 남양주시장 표창장" },
    { year: "2023", event: "경기도 중소기업 벤치기업 청장 표창장" },
    { year: "2023", event: "경기도중소기업CEO연합회 남양주 지회 11대 · 12대 회장 역임" },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[200px] md:h-[300px] bg-zinc-800 overflow-hidden">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div className="absolute inset-0 bg-zinc-900">
          <Image
            src="https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1920&q=80"
            alt="세광정밀 공장 내부"
            fill
            className="object-cover opacity-80"
            priority
          />
        </div>
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-white text-center px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">회사 소개</h1>
          <p className="text-zinc-300">최고의 품질과 기술력으로 고객의 신뢰에 보답합니다</p>
        </div>
      </section>

      {/* Tabs */}
      <div className="border-b border-zinc-200 bg-white sticky top-0 z-30">
        <div className="max-w-4xl mx-auto">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-4 text-center text-sm md:text-base transition-colors ${
                  activeTab === tab.id 
                    ? "bg-zinc-900 text-white font-medium" 
                    : "bg-white text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 bg-white">
        {activeTab === "greeting" && (
          <section className="py-12 md:py-20">
            <div className="max-w-3xl mx-auto px-4 text-center">
              <div className="flex items-center justify-center mb-8">
                <Image
                  src="https://res.cloudinary.com/dhcbbnwkg/image/upload/v1778564035/%E1%84%89%E1%85%A6%E1%84%80%E1%85%AA%E1%86%BC%E1%84%8C%E1%85%A5%E1%86%BC%E1%84%86%E1%85%B5%E1%86%AF_%E1%84%85%E1%85%A9%E1%84%80%E1%85%A9_myhsls.png"
                  alt="세광정밀 로고"
                  width={200}
                  height={60}
                  className="h-12 md:h-16 w-auto"
                />
              </div>
              
              <div className="space-y-6 text-zinc-600 leading-relaxed">
                <p>세광정밀에 방문해 주셔서 감사합니다.</p>
                <p>저희 세광정밀은 1998년 설립 이래로 40년의 경력과 노하우로</p>
                <p>고객 신뢰를 우선으로 생각하며, 최고 품질의 제품을 제공하고 있습니다.</p>
                <p>맞춤형 볼트 및 리벳 부터 일반형 피스, 너트, 볼트, 핀, 홈 가공 까지 고객 요구에 최적화된 제품을 제공합니다.</p>
                <p>항상 고객 감동과 최고의 품질을 제공하기 위해 최선을 다해 앞장서는 기업이 되겠습니다.</p>
              </div>
              
              <p className="mt-10 font-medium">세광정밀 대표 이승구</p>
            </div>
          </section>
        )}

        {activeTab === "history" && (
          <section className="py-12 md:py-20 bg-zinc-50">
            <div className="max-w-3xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">연혁</h2>
              <div className="space-y-4">
                {history.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-4 py-2 border-b border-zinc-200">
                    <span className="col-span-2 text-zinc-500 font-medium">{item.year}</span>
                    <span className="col-span-10 text-zinc-700">{item.event}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {activeTab === "contact" && (
          <section className="py-12 md:py-20">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-10">연락처</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Mail className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">E-mail</p>
                  <p className="font-medium">sekwangfastener@gmail.com</p>
                </div>
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Phone className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">대표전화</p>
                  <p className="font-medium">031) 573 - 5547</p>
                  <p className="font-medium">031) 573 - 5548</p>
                </div>
                <div className="border border-zinc-200 rounded-lg p-6 md:p-8 text-center">
                  <Printer className="w-8 h-8 mx-auto mb-4 text-zinc-400" />
                  <p className="text-sm text-zinc-500 mb-2">Fax</p>
                  <p className="font-medium">031) 571 - 3567</p>
                </div>
              </div>
            </div>
          </section>
        )}

        {activeTab === "location" && (
          <section className="py-12 md:py-20 bg-zinc-50">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="text-2xl md:text-3xl font-medium text-center mb-6">오시는 길</h2>
              <p className="text-center text-zinc-600 mb-8 flex items-center justify-center gap-2">
                <MapPin className="w-5 h-5" />
                경기도 남양주시 진접읍 부마로 54-16
              </p>
              <div className="aspect-video bg-zinc-200 rounded-lg overflow-hidden relative">
                {/* 네이버 지도 - 경기도 남양주시 진접읍 부마로 54-16 */}
                <iframe 
                  src="https://map.naver.com/p/embed/place/1102313986?c=15.00,0,0,0,dh"
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  title="세광정밀 위치"
                ></iframe>
              </div>
              <div className="mt-4 text-center">
                <a 
                  href="https://map.naver.com/p/search/%EA%B2%BD%EA%B8%B0%EB%8F%84%20%EB%82%A8%EC%96%91%EC%A3%BC%EC%8B%9C%20%EC%A7%84%EC%A0%91%EC%9D%8D%20%EB%B6%80%EB%A7%88%EB%A1%9C%2054-16"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm text-zinc-600 hover:text-zinc-900 transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  네이버 지도에서 크게 보기
                </a>
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  )
}

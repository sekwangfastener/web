"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { Phone, Menu, X } from "lucide-react"
import { useState } from "react"

const LOGO_URL = "https://res.cloudinary.com/dhcbbnwkg/image/upload/v1778564035/%E1%84%89%E1%85%A6%E1%84%80%E1%85%AA%E1%86%BC%E1%84%8C%E1%85%A5%E1%86%BC%E1%84%86%E1%85%B5%E1%86%AF_%E1%84%85%E1%85%A9%E1%84%80%E1%85%A9_myhsls.png"

export function Header() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="w-full">
      {/* Top bar */}
      <div className="bg-zinc-900 text-white text-xs md:text-sm py-2">
        <div className="max-w-6xl mx-auto px-4 flex flex-wrap justify-center md:justify-start gap-4 md:gap-8">
          <span className="flex items-center gap-1">
            <Phone className="w-3 h-3" />
            Phone 031) 573 - 5547 · 031) 573 - 5548
          </span>
          <span className="hidden md:inline">⊕ FAX 031)571 - 3567</span>
          <span className="hidden md:inline">✉ Email sekwangfastener@gmail.com</span>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="bg-white border-b border-zinc-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image
              src={LOGO_URL}
              alt="세광정밀 로고"
              width={140}
              height={40}
              className="h-8 md:h-10 w-auto"
              priority
            />
          </Link>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link 
              href="/about" 
              className={`hover:text-zinc-600 transition-colors ${pathname === '/about' ? 'font-medium' : ''}`}
            >
              회사 소개
            </Link>
            <Link 
              href="/products" 
              className={`hover:text-zinc-600 transition-colors ${pathname === '/products' ? 'font-medium' : ''}`}
            >
              제품
            </Link>
          </div>

          {/* Mobile menu button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-zinc-200">
            <Link 
              href="/about" 
              className="block px-4 py-3 hover:bg-zinc-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              회사 소개
            </Link>
            <Link 
              href="/products" 
              className="block px-4 py-3 hover:bg-zinc-50"
              onClick={() => setMobileMenuOpen(false)}
            >
              제품
            </Link>
          </div>
        )}
      </nav>
    </header>
  )
}
